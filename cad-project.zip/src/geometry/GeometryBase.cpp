/*
 * GeometryBase.cpp
 *
 *  Created on: Dec 10, 2014
 *      Author: albuscrow
 */
#include <geometry/GeometryBase.h>

namespace cad{

GeometryBase::~GeometryBase(){
}

GeometryBase::GeometryBase(){
}
}


